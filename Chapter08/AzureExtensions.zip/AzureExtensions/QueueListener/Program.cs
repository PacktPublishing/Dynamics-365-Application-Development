﻿using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace QueueTopicListener
{
    class AzureExample
    {
        static void Main(string[] args)
        {
            QueueClientExample();
            SubcriptionClientExample();
        }  
        

        private static void QueueClientExample()
        {

            // set the connection string of the Shared Access Policy created for the Queue
            var connectionString = "Endpoint=sb://[namespace].servicebus.windows.net/;SharedAccessKeyName=[KeyName];SharedAccessKey=[KeyValue];EntityPath=[QueueName]";

            // create the Queue Client object
            var client = QueueClient.CreateFromConnectionString(connectionString);

            // get the message from the Queue Client
            BrokeredMessage brokeredMessage = client.Receive();

            // get the Remote Execution Context passed from the Azure Service Bus
            RemoteExecutionContext context = brokeredMessage.GetBody<RemoteExecutionContext>();

            // cast to Entity object
            Entity entity = (Entity)context.InputParameters["Target"];

            // get the lead's topic attribute value
            var leadTopic = entity.Attributes["subject"].ToString();

            // output to console
            Console.WriteLine(string.Format("   Entity Name = {0}, Message Name = {1}, Lead's Topic = {2}",
                context.PrimaryEntityName, context.MessageName, leadTopic));
        }

        private static void SubcriptionClientExample()
        {
            // set the connection string of the Shared Access Policy created for the Subscription
            // along with name of the Topic and Subcription           
            var connectionString = "Endpoint=sb://dynamics365sampleservicebus.servicebus.windows.net/;SharedAccessKeyName=Dynamics365Policy;SharedAccessKey=xMezhwC3hJUN45/2T9nt5W+PoTdi0UJXRqKhVlnKUrg=;EntityPath=dynamics365topic";
            var topic = "dynamics365topic";
            var subscriptionName = "Dynamics365Subscription";

            // create the Subcription Client object
            var client = SubscriptionClient.CreateFromConnectionString(connectionString, topic, subscriptionName);

            // get the message from the Queue Client
            BrokeredMessage brokeredMessage = client.Receive();

            // get the Remote Execution Context passed from the Azure Service Bus
            RemoteExecutionContext context = brokeredMessage.GetBody<RemoteExecutionContext>();

            // cast to Entity object
            Entity entity = (Entity)context.InputParameters["Target"];

            // get the lead's topic attribute value
            var leadTopic = entity.Attributes["subject"].ToString();

            // output to console
            Console.WriteLine(string.Format("  Entity Name = {0}, Message Name = {1}, Lead's Topic = {2}",
                context.PrimaryEntityName, context.MessageName, leadTopic));
        }

      
    }
}
