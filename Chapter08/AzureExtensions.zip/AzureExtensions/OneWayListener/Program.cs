﻿using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace OneWayListener
{
    [ServiceBehavior]
    class AzureExample : IServiceEndpointPlugin
    {
        static void Main(string[] args)
        {
            // get the shared access key name
            // shared access key value
            // service bus endpoint from the Shared Access Policy Connection String.
            var sharedAccessKeyName = "RootManageSharedAccessKey";
            var sharedAccessKey = "jZCQzxpuB/Lwt/a0VxaZ8lnntjL9DzLZ6mWTDjET0hY=";
            var serviceBusEndPoint = "https://dynamics365sampleservicebus.servicebus.windows.net";

            // initialize the ServiceHost 
            var serviceHost = new ServiceHost(typeof(AzureExample));

            // define the behaviour
            var transportClient = new TransportClientEndpointBehavior
                (TokenProvider.CreateSharedAccessSignatureTokenProvider(sharedAccessKeyName, sharedAccessKey));

            // add the service endpoint
            serviceHost.AddServiceEndpoint(typeof(IServiceEndpointPlugin),
                new WS2007HttpRelayBinding(), serviceBusEndPoint).EndpointBehaviors.Add(transportClient);

            serviceHost.Open();

            Console.ReadLine();
        }

        void IServiceEndpointPlugin.Execute(RemoteExecutionContext context)
        {
            // cast to Entity object
            Entity entity = (Entity)context.InputParameters["Target"];

            // get the lead's topic attribute value
            var leadTopic = entity.Attributes["subject"].ToString();

            // output to console
            Console.WriteLine(string.Format("  Entity Name = {0}, Message Name = {1}, Lead's Topic = {2}",
                context.PrimaryEntityName, context.MessageName, leadTopic));
        }  
    }
}
