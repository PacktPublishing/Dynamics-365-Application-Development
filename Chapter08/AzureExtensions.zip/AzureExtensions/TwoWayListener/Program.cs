﻿using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;

namespace RestListener
{
    class AzureExample : IWebHttpServiceEndpointPlugin
    {
        static void Main(string[] args)
        {
            // get the shared access key name
            // shared access key value
            // service bus endpoint from the Shared Access Policy Connection String.
            var sharedAccessKeyName = "RootManageSharedAccessKey";
            var sharedAccessKey = "jZCQzxpuB/Lwt/a0VxaZ8lnntjL9DzLZ6mWTDjET0hY=";
            var serviceBusEndPoint = "https://dynamics365sampleservicebus.servicebus.windows.net";
            
            // Create the service host for Azure to post messages to.
            var serviceHost = new WebServiceHost(typeof(AzureExample));

            // define the behaviour
            var transportClient = new TransportClientEndpointBehavior
                (TokenProvider.CreateSharedAccessSignatureTokenProvider(sharedAccessKeyName, sharedAccessKey));


            // Using an HTTP binding instead of a SOAP binding for this RESTful endpoint.
            WebHttpRelayBinding binding = new WebHttpRelayBinding();
            binding.Security.Mode = EndToEndWebHttpSecurityMode.Transport;

            // add the service endpoint
            serviceHost.AddServiceEndpoint(typeof(IWebHttpServiceEndpointPlugin),
               binding, serviceBusEndPoint).EndpointBehaviors.Add(transportClient);

            // Begin listening for messages posted to Azure.
            serviceHost.Open();           

            Console.ReadLine();
        }

        string IWebHttpServiceEndpointPlugin.Execute(RemoteExecutionContext context)
        {
            // cast to Entity object
            Entity entity = (Entity)context.InputParameters["Target"];

            // get the lead's topic attribute value
            var leadTopic = entity.Attributes["subject"].ToString();

            // output to console
            Console.WriteLine(string.Format("  Entity Name = {0}, Message Name = {1}, Lead's Topic = {2}",
                context.PrimaryEntityName, context.MessageName, leadTopic));

            // return the message back to the custom azure aware plugin
            return "Message Processed by Rest Listener";
        }

    }
}
