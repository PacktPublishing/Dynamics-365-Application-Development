﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace AzureSample
{
    public class AzureAwarePlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            // set the Service Endpoint Id
            var serviceEndpointId = "5f0d7045-1aa0-e711-8130-c4346bdc1f11";

            // Obtain the execution context from the service provider.
            IPluginExecutionContext context = (IPluginExecutionContext)
                serviceProvider.GetService(typeof(IPluginExecutionContext));

            //Extract the tracing service for use in debugging sandboxed plug-ins.
            ITracingService tracingService =
                (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            // Extract the notification service for posting execution context
            IServiceEndpointNotificationService notificationService = (IServiceEndpointNotificationService)
                serviceProvider.GetService(typeof(IServiceEndpointNotificationService));

            var response = notificationService.Execute(new EntityReference("serviceendpoint", new Guid(serviceEndpointId)), context);

            if (!string.IsNullOrEmpty(response))
            {
                tracingService.Trace("Response = {0}", response);
            }
        }
    }
}
