﻿function CallAction() { 

    // get the id of the record and remove the curly bracket part
    // id will be used in Web API url
    var Id = Xrm.Page.data.entity.getId().replace('{', '').replace('}', '');

    var serverURL = Xrm.Page.context.getClientUrl();

   // pass the id as inpurt parameter
    var data = {

        "recordid": Id
    }; 

    var req = new XMLHttpRequest();

    // specify name of the entity, record id and name of the action in the Wen API Url
    req.open("POST", serverURL + "/api/data/v8.2/sab_costmanagements(" + Id + ")/Microsoft.Dynamics.CRM.sab_Recalculate", true);

    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.onreadystatechange = function () {
        if (this.readyState == 4 /* complete */) {
            req.onreadystatechange = null;
            if (this.status == 200) {
                var data = JSON.parse(this.response);              
                alert(data);
            } else {
                var error = JSON.parse(this.response).error;
                alert(error.message);
            }
        }
    };

    // send the request with the data for the input parameter
    req.send(window.JSON.stringify(data));
}